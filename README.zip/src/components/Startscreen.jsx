import {useState} from "react";
import {BrowserRouter as Router, Routes, Route, Link, useNavigate} from "react-router-dom";
import Game from "./Game.jsx";

export default function Startscreen ({inplegs, setInplegs}){
    const navigate = useNavigate()
    function HandleChange(e){
        e.preventDefault()
        setInplegs(e.target.value)
    }
    function HandleSubmit(e){
        e.preventDefault()
        navigate("/Game")
    }
    return(
        
        <div className={"legdiv"}>
            <form onSubmit={HandleSubmit}>
                <input id={"inpleg"} value={inplegs} onChange={HandleChange}/>
                <label htmlFor={"inpleg"}>auf wie viele Legs soll gespielt werden?</label>
                <button type={"submit"}>submit</button>
            </form>
        </div>
    )
}